﻿
export * from './contact.component';