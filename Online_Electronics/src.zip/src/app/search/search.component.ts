import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Data } from '@app/_models';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  //template: '<div><input type="text" [(ngModel)]="term"><div *ngFor = "let item of items |filter:term"><p>{{item.name}}</p></div></div>',
  styleUrls: ['./search.component.css']
})

export class SearchComponent implements OnInit {
  
  data: Data[] = [];
  //items: myArray<{name:string}> = [{ name: 'archie' }, { name: 'jake' }, { name: 'richard' }];
  
  constructor(private http: HttpClient) { 
    this.getJSON().subscribe(data => {
      this.data = data;
  });
  }
  public getJSON(): Observable<any> {
    return this.http.get("./assets/Employee.json");
}

  ngOnInit() {
  }
  handleClick(event: Event) {
    alert("Haii");
  }
  
}
