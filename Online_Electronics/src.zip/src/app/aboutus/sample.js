﻿function sample()
{
	alert('Haii');
}