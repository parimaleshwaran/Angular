import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Data } from '@app/_models';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  public id:string;
  data: Data[] = [];
  curr_prod: Data;
  temp_result: Data[] = [];
  cart = [];
   constructor( private route: ActivatedRoute, private http: HttpClient,) { 
     this.getJSON().subscribe(data => {
       this.data = data;
   });}
   public getJSON(): Observable<any> {
    return this.http.get("./assets/Employee.json");
}
  ngOnInit() {
    this.route.params.subscribe(paramsId => { this.id = paramsId.id});
  }
addToCart(Prodid:number)
{
	console.log(this.data);
	for (let i of this.data)
	{
		if (i.product_id == Prodid)
			this.curr_prod = i;
	}
	//console.log(this.curr_prod);
	this.temp_result = JSON.parse(localStorage.getItem('cart'));
	console.log(this.temp_result);
	if(this.temp_result == null || this.temp_result.length <1)
	{
		this.cart.push(this.curr_prod);
		localStorage.setItem('cart',JSON.stringify(this.cart));
	}
	else{
		//this.cart.push(this.temp_result);
		this.temp_result.push(this.curr_prod);
		//console.log("My Cart");
		//console.log(this.cart);
		localStorage.setItem('cart',JSON.stringify(this.temp_result));
	}
	//this.temp_result.push(this.curr_prod);
	//console.log(this.temp_result);
	//localStorage.setItem('result',JSON.stringify(this.temp_result));
	
	alert('Product Added To Your Cart Successfully');
}
}
