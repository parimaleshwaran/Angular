import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Data } from '@app/_models';


@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  //template: '<div><input type="text" [(ngModel)]="term"><div *ngFor = "let item of items |filter:term"><p>{{item.name}}</p></div></div>',
  styleUrls: ['./sample.component.css']
})

/*
@Component({
  selector: 'app-sample',
  template: '<input #newHero (keyup.enter)="addHero(newHero.value)" (blur)="addHero(newHero.value); newHero.value='' "><button (click)="addHero(newHero.value)">Add</button><ul><li *ngFor="let hero of heroes">{{hero}}</li></ul>',
})*/
export class SampleComponent implements OnInit {
  
  data: Data[] = [];
  result = []
  heroes = ['Windstorm', 'Bombasto', 'Magneta', 'Tornado'];
  //items: myArray<{name:string}> = [{ name: 'archie' }, { name: 'jake' }, { name: 'richard' }];
  
  constructor(private http: HttpClient) { 
    this.getJSON().subscribe(data => {
      this.data = data;
  });
  }
  public getJSON(): Observable<any> {
    return this.http.get("./assets/Employee.json");
}

  addHero(newHero: string) {
    if (newHero) {
      this.heroes.push(newHero);
    }
  }
  search(newHero: string) {
    if (newHero) {
		for (let i in this.data){
			if(this.data[i].product_name.includes(newHero))
			{
				//console.log('Correct'+newHero);
				//console.log(this.data[i].product_name);
				this.result.push(this.data[i].product_name)
			}
			else
			{
				console.log('Wrong'+newHero);
			}
		}
    }
	return this.result;
  }
  ngOnInit() {
  }
  handleClick(event: Event) {
    alert("Haii");
  }
  
}
