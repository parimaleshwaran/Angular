import { Component, OnInit } from '@angular/core';
import { Data } from '@app/_models';

@Component({
  selector: 'app-mycart',
  templateUrl: './mycart.component.html',
  styleUrls: ['./mycart.component.css']
})
export class MycartComponent implements OnInit {
	cart: Data[] = [];
	tot_amount:number = 0;
	count:number = 0;
	index:number = 0;
	
  constructor() {
	  this.cart = JSON.parse(localStorage.getItem('cart'));
	  if(this.cart != null)
	  {
	  for (let i of this.cart) {
			this.tot_amount += Number(i.product_price);
	  }}
	  else
	  {
		  this.cart = [];
	  }
	  console.log(this.cart);
		}
		
	removeItem(prod_id:number)
	{
		this.index=0;
		this.count=0;
		for (let i of this.cart) {
			if(i.product_id == prod_id)
			{
				this.index = this.count;
			}
			else
			{
				this.count += 1;
			}
		}
		this.cart.splice(this.index,1);
		this.tot_amount = 0;
		for (let i of this.cart) {this.tot_amount += Number(i.product_price);}
		localStorage.setItem('cart',JSON.stringify(this.cart));
		alert('Removed Successfully');
	}
	
  ngOnInit() {
  }

}
