import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searches',
  templateUrl: './searches.component.html',
  styleUrls: ['./searches.component.css']
})
export class SearchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
