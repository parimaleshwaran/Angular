import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Data } from '@app/_models';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  //template: '<div><input type="text" [(ngModel)]="term"><div *ngFor = "let item of items |filter:term"><p>{{item.name}}</p></div></div>',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {
  
  data: Data[] = [];
  result: Data[] = [];
  //items: myArray<{name:string}> = [{ name: 'archie' }, { name: 'jake' }, { name: 'richard' }];
  
  constructor(private http: HttpClient) { 
    this.getJSON().subscribe(data => {
      this.data = data;
	  this.result = data;
	  //localStorage.setItem('result',JSON.stringify(this.result));
		
  });
  }
  public getJSON(): Observable<any> {
    return this.http.get("./assets/Employee.json");
}
searchFunction(searchTerm: string) {
	this.result = [];
		if (searchTerm.length > 0) {
			for (let i in this.data){
				if(((this.data[i].product_name).toLowerCase()).includes(searchTerm.toLowerCase()))
				{
					//console.log('Correct'+newHero);
					//console.log(this.data[i].product_name);
					this.result.push(this.data[i])
				}
			}
			console.log(this.result);
		}
		else{
			this.result = this.data;
		}
		return this.result;
	}
  ngOnInit() {
  }
  
}
