export class Data {
   product_id: number;
   product_name: string;
   product_location: string;
   product_price: number;
   product_type:string;
   product_model:string;
   

}
