﻿import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';
import { ProductsComponent } from './products';
import { AboutusComponent } from './aboutus';
import { ProductComponent } from './product';
import { AuthGuard } from './_guards';
import { SampleComponent } from './sample';
import { SearchComponent } from './search';
import { MycartComponent } from './mycart';
import { ContactComponent } from './contact';

const appRoutes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
       { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
	{ path: 'products', component: ProductsComponent },
    { path: 'aboutus', component: AboutusComponent },
    { path: 'product/:id', component: ProductComponent },
    { path: 'search', component: SearchComponent },
	{ path: 'sample', component: SampleComponent },
	{ path: 'mycart', component: MycartComponent },
	{ path: 'contact', component: ContactComponent },
	
{ path: '**', redirectTo: '' },
];

export const routing = RouterModule.forRoot(appRoutes);